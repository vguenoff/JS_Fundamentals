$.fn.gallery = function (col) {
    
};