var r = 3,
    s = Math.PI * Math.pow(r, 2);

console.log(s);