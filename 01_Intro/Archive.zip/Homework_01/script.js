var a = 2;

var theNumber = (a & 1) ? 'odd' : 'even';
console.log('The number is ' + theNumber + '.');