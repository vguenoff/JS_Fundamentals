function createCalendar(selector, events) {
    'use strict';

}